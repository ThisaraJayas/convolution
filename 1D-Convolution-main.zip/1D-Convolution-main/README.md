# 1D-Convolution
google colab
